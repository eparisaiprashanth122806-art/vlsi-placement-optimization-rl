from environment.vlsi_env import VLSIPlacementEnv
from agent.dqn_agent import Agent
from environment.placement_utils import plot_placement_3d, animate_placement
import matplotlib.pyplot as plt
import csv
import os

# ✅ CREATE RESULTS FOLDER
os.makedirs("results", exist_ok=True)

# 🔥 CREATE ENVIRONMENT
env = VLSIPlacementEnv()

NUM_CELLS = env.num_cells
print(f"🔷 Circuit loaded with {NUM_CELLS} cells")

state_size = env.observation_space.shape[0] * 2
action_size = env.action_space.n

agent = Agent(state_size, action_size)

# ⚡ PARAMETERS
episodes = 20
steps_per_episode = 60

rewards_list = []
history = []   # 🔥 for animation

# 🔴 BEFORE OPTIMIZATION
state = env.reset()
initial_wire = env.calculate_wire_length()

plot_placement_3d(
    state,
    f"3D Before Optimization ({NUM_CELLS} Cells)",
    env.connections,
    env.node_types
)

# 🔁 TRAINING LOOP
for ep in range(episodes):
    total_reward = 0

    for t in range(steps_per_episode):
        action = agent.select_action(state)
        next_state, reward, done, _ = env.step(action)

        agent.train(state, action, reward, next_state)

        state = next_state
        total_reward += reward

        # 🔥 store positions for animation
        history.append(state.copy())

    rewards_list.append(total_reward)
    print(f"Episode {ep+1}, Reward: {total_reward:.2f}")

# 🟢 AFTER OPTIMIZATION
final_wire = env.calculate_wire_length()

plot_placement_3d(
    state,
    f"3D After Optimization ({NUM_CELLS} Cells)",
    env.connections,
    env.node_types
)

# 🎥 ANIMATION (BIG FEATURE)
print("\n🎥 Showing optimization animation...")
animate_placement(history, env.connections, env.node_types)

# 📊 SAVE RESULTS
with open('results/output.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['Episode', 'Reward'])
    for i, reward in enumerate(rewards_list):
        writer.writerow([i+1, reward])

# 📊 TRAINING GRAPH
plt.figure(figsize=(12, 6))
plt.plot(rewards_list, marker='o')
plt.xlabel("Episodes", fontsize=14)
plt.ylabel("Total Reward", fontsize=14)
plt.title("Training Progress (Optimization)", fontsize=16)
plt.grid()
plt.show()

# 📊 WIRE LENGTH COMPARISON GRAPH (NEW)
plt.figure(figsize=(6,4))
plt.bar(["Before", "After"], [initial_wire, final_wire])
plt.title("Wirelength Comparison")
plt.ylabel("Wire Length")
plt.show()

# 📊 PRINT VALUES
print("\n📊 Wire Length Comparison:")
print(f"Before Optimization : {initial_wire:.2f}")
print(f"After Optimization  : {final_wire:.2f}")
print(f"Improvement         : {initial_wire - final_wire:.2f}")