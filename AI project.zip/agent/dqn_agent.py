import torch
import torch.optim as optim
from agent.model import DQN

class Agent:

    def __init__(self, state_size, action_size):
        self.model = DQN(state_size, action_size)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.001)
        self.gamma = 0.99

    def select_action(self, state):
        state = torch.FloatTensor(state.flatten()).unsqueeze(0)
        q_values = self.model(state)
        return torch.argmax(q_values).item()

    def train(self, state, action, reward, next_state):
        state = torch.FloatTensor(state.flatten()).unsqueeze(0)
        next_state = torch.FloatTensor(next_state.flatten()).unsqueeze(0)

        q_values = self.model(state)
        next_q_values = self.model(next_state)

        target = q_values.clone()
        target[0][action] = reward + self.gamma * torch.max(next_q_values)

        loss = (q_values - target).pow(2).mean()

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()