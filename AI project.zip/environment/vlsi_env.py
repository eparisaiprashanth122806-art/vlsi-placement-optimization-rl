import numpy as np
import gym
from gym import spaces
from environment.bench_parser import parse_bench

GRID_SIZE = 50

class VLSIPlacementEnv(gym.Env):

    def __init__(self):
        super(VLSIPlacementEnv, self).__init__()

        # 🔥 LOAD REAL CIRCUIT
        nodes, edges, node_types = parse_bench("benchmarks/c432.bench")

        # ✅ SAFETY CHECK
        if len(nodes) == 0:
            raise ValueError("❌ ERROR: No nodes loaded from .bench file. Check file path or content.")

        self.num_cells = len(nodes)

        # ⚡ limit connections for performance
        self.connections = edges[:60]

        self.node_types = node_types

        print(f"✅ Loaded circuit with {self.num_cells} cells and {len(self.connections)} connections")

        # Action space
        self.action_space = spaces.Discrete(self.num_cells * GRID_SIZE * GRID_SIZE)

        # State space
        self.observation_space = spaces.Box(
            low=0,
            high=GRID_SIZE,
            shape=(self.num_cells, 2),
            dtype=np.int32
        )

        self.reset()

    def reset(self):
        self.cells = np.random.randint(0, GRID_SIZE, (self.num_cells, 2))
        return self.cells

    def step(self, action):
        cell_id = action // (GRID_SIZE * GRID_SIZE)
        pos = action % (GRID_SIZE * GRID_SIZE)

        x = pos // GRID_SIZE
        y = pos % GRID_SIZE

        self.cells[cell_id] = [x, y]

        wire_length = self.calculate_wire_length()

        # overlap penalty
        unique_positions = set(tuple(cell) for cell in self.cells)
        overlap_penalty = 50 if len(unique_positions) < len(self.cells) else 0

        reward = -wire_length - overlap_penalty

        done = False
        return self.cells, reward, done, {}

    def calculate_wire_length(self):
        total = 0

        for (i, j) in self.connections:
            if i < self.num_cells and j < self.num_cells:
                # ⚡ faster distance (better for large circuits)
                total += abs(self.cells[i][0] - self.cells[j][0]) + \
                         abs(self.cells[i][1] - self.cells[j][1])

        return total