import re

def parse_bench(file_path):
    nodes = {}
    edges = []
    node_types = {}
    node_index = 0

    def get_node(name, ntype="WIRE"):
        nonlocal node_index
        name = name.strip()
        if name not in nodes:
            nodes[name] = node_index
            node_types[node_index] = ntype
            node_index += 1
        return nodes[name]

    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            # INPUT
            if line.startswith("INPUT"):
                name = re.findall(r'\((.*?)\)', line)[0]
                get_node(name, "INPUT")

            # OUTPUT
            elif line.startswith("OUTPUT"):
                name = re.findall(r'\((.*?)\)', line)[0]
                get_node(name, "OUTPUT")

            # GATES
            elif '=' in line:
                left, right = line.split('=')
                output = left.strip()

                gate_type = right.split('(')[0].strip()
                inputs = re.findall(r'\((.*?)\)', right)[0].split(',')

                out_id = get_node(output, gate_type)

                for inp in inputs:
                    in_id = get_node(inp)
                    edges.append((in_id, out_id))

    return nodes, edges, node_types