import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.lines import Line2D
from matplotlib.animation import FuncAnimation

# 🎨 color + marker mapping
def get_style(ntype):
    if ntype == "INPUT":
        return "green", "o"
    elif ntype == "OUTPUT":
        return "red", "s"
    elif ntype == "AND":
        return "blue", "^"
    elif ntype == "OR":
        return "orange", "v"
    elif ntype == "NAND":
        return "purple", "D"
    elif ntype == "NOR":
        return "brown", "P"
    else:
        return "gray", "o"


# =========================
# 🔹 STATIC PLOT
# =========================
def plot_placement_3d(cells, title, connections, node_types):

    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')

    x = cells[:, 0]
    y = cells[:, 1]
    z = np.linspace(0, 10, len(cells))

    for i in range(len(cells)):
        ntype = node_types.get(i, "WIRE")
        color, marker = get_style(ntype)

        ax.scatter(x[i], y[i], z[i], color=color, marker=marker, s=120)

        if i < 20:
            ax.text(x[i], y[i], z[i], ntype, fontsize=7)

    # connections
    for (i, j) in connections:
        if i < len(cells) and j < len(cells):
            ax.plot([x[i], x[j]],
                    [y[i], y[j]],
                    [z[i], z[j]],
                    color='gray', alpha=0.3)

    # 🔥 LEGEND
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', label='INPUT', markerfacecolor='green', markersize=10),
        Line2D([0], [0], marker='s', color='w', label='OUTPUT', markerfacecolor='red', markersize=10),
        Line2D([0], [0], marker='^', color='w', label='AND', markerfacecolor='blue', markersize=10),
        Line2D([0], [0], marker='v', color='w', label='OR', markerfacecolor='orange', markersize=10),
        Line2D([0], [0], marker='D', color='w', label='NAND', markerfacecolor='purple', markersize=10),
        Line2D([0], [0], marker='P', color='w', label='NOR', markerfacecolor='brown', markersize=10),
    ]

    ax.legend(handles=legend_elements, loc='upper right')

    # 🔥 SYMBOL TEXT (your requirement)
    ax.text2D(0.02, 0.95,
              "● INPUT\n■ OUTPUT\n▲ AND\n▼ OR\n◆ NAND\n⬟ NOR",
              transform=ax.transAxes,
              fontsize=10,
              verticalalignment='top')

    ax.set_title(title)
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Layer")

    plt.tight_layout()
    plt.show()


# =========================
# 🔹 ANIMATION FUNCTION
# =========================
def animate_placement(history, connections, node_types):

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    z = np.linspace(0, 10, history[0].shape[0])

    # 🔥 wirelength calculation
    def calc_wire(cells):
        total = 0
        for (i, j) in connections:
            if i < len(cells) and j < len(cells):
                total += abs(cells[i][0] - cells[j][0]) + abs(cells[i][1] - cells[j][1])
        return total

    def update(frame):
        ax.clear()

        cells = history[frame]
        x = cells[:, 0]
        y = cells[:, 1]

        for i in range(len(cells)):
            ntype = node_types.get(i, "WIRE")
            color, marker = get_style(ntype)

            ax.scatter(x[i], y[i], z[i], color=color, marker=marker, s=100)

        # connections
        for (i, j) in connections:
            if i < len(cells) and j < len(cells):
                ax.plot([x[i], x[j]],
                        [y[i], y[j]],
                        [z[i], z[j]],
                        color='gray', alpha=0.3)

        # 🔥 LIVE INFO
        wire = calc_wire(cells)

        ax.set_title(f"Step {frame+1} / {len(history)}  |  Wirelength: {wire:.2f}")
        ax.set_xlabel("X")
        ax.set_ylabel("Y")
        ax.set_zlabel("Layer")

        # 🔥 SYMBOL LEGEND INSIDE
        ax.text2D(0.02, 0.95,
                  "● INPUT\n■ OUTPUT\n▲ AND\n▼ OR\n◆ NAND\n⬟ NOR",
                  transform=ax.transAxes,
                  fontsize=9,
                  verticalalignment='top')

    ani = FuncAnimation(fig, update, frames=len(history), interval=200)
    plt.show()